﻿namespace JWTAuthentication.DTOs
{
    public class EmployeeDTO
    {

    }
}
